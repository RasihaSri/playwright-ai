/* esm.sh - es-toolkit@1.46.1/compat/isPlainObject */
export * from "/es-toolkit@1.46.1/es2022/compat/isPlainObject.mjs";
export { default } from "/es-toolkit@1.46.1/es2022/compat/isPlainObject.mjs";
