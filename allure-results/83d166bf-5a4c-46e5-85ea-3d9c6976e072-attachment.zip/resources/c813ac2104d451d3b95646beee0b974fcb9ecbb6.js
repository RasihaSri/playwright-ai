/* esm.sh - es-toolkit@1.46.1/compat/minBy */
export * from "/es-toolkit@1.46.1/es2022/compat/minBy.mjs";
export { default } from "/es-toolkit@1.46.1/es2022/compat/minBy.mjs";
