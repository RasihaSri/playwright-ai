/* esm.sh - es-toolkit@1.46.1/compat/last */
export * from "/es-toolkit@1.46.1/es2022/compat/last.mjs";
export { default } from "/es-toolkit@1.46.1/es2022/compat/last.mjs";
