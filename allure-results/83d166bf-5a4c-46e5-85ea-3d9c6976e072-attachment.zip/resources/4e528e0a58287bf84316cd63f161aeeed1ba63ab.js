/* esm.sh - use-sync-external-store@1.6.0/with-selector */
import "/react@^19.2.0?target=es2022";
export * from "/use-sync-external-store@1.6.0/es2022/with-selector.mjs";
export { default } from "/use-sync-external-store@1.6.0/es2022/with-selector.mjs";
