/* esm.sh - react-hot-toast@2.6.0 */
"use client";import{useEffect as q,useState as G,useRef as J}from"/react@>=16?target=es2022";import{useEffect as j,useCallback as x,useRef as ee}from"/react@>=16?target=es2022";import*as h from"/react@>=16?target=es2022";import{styled as F,keyframes as M}from"/goober@^2.1.16?target=es2022";import*as b from"/react@>=16?target=es2022";import{styled as O,keyframes as se}from"/goober@^2.1.16?target=es2022";import{styled as re,keyframes as P}from"/goober@^2.1.16?target=es2022";import{styled as de,keyframes as ce}from"/goober@^2.1.16?target=es2022";import{styled as ue,keyframes as U}from"/goober@^2.1.16?target=es2022";import{css as Oe,setup as Pe}from"/goober@^2.1.16?target=es2022";import*as v from"/react@>=16?target=es2022";var Y=e=>typeof e=="function",D=(e,t)=>Y(e)?e(t):e,_=(()=>{let e=0;return()=>(++e).toString()})(),L=(()=>{let e;return()=>{if(e===void 0&&typeof window<"u"){let t=matchMedia("(prefers-reduced-motion: reduce)");e=!t||t.matches}return e}})(),K=20,A="default",R=(e,t)=>{let{toastLimit:a}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,a)};case 1:return{...e,toasts:e.toasts.map(s=>s.id===t.toast.id?{...s,...t.toast}:s)};case 2:let{toast:r}=t;return R(e,{type:e.toasts.find(s=>s.id===r.id)?1:0,toast:r});case 3:let{toastId:o}=t;return{...e,toasts:e.toasts.map(s=>s.id===o||o===void 0?{...s,dismissed:!0,visible:!1}:s)};case 4:return t.toastId===void 0?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(s=>s.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(s=>({...s,pauseDuration:s.pauseDuration+i}))}}},$=[],S={toasts:[],pausedAt:void 0,settings:{toastLimit:K}},f={},H=(e,t=A)=>{f[t]=R(f[t]||S,e),$.forEach(([a,r])=>{a===t&&r(f[t])})},B=e=>Object.keys(f).forEach(t=>H(e,t)),Q=e=>Object.keys(f).find(t=>f[t].toasts.some(a=>a.id===e)),I=(e=A)=>t=>{H(t,e)},W={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},X=(e={},t=A)=>{let[a,r]=G(f[t]||S),o=J(f[t]);q(()=>(o.current!==f[t]&&r(f[t]),$.push([t,r]),()=>{let s=$.findIndex(([p])=>p===t);s>-1&&$.splice(s,1)}),[t]);let i=a.toasts.map(s=>{var p,g,y;return{...e,...e[s.type],...s,removeDelay:s.removeDelay||((p=e[s.type])==null?void 0:p.removeDelay)||e?.removeDelay,duration:s.duration||((g=e[s.type])==null?void 0:g.duration)||e?.duration||W[s.type],style:{...e.style,...(y=e[s.type])==null?void 0:y.style,...s.style}}});return{...a,toasts:i}},Z=(e,t="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:a?.id||_()}),w=e=>(t,a)=>{let r=Z(t,e,a);return I(r.toasterId||Q(r.id))({type:2,toast:r}),r.id},l=(e,t)=>w("blank")(e,t);l.error=w("error");l.success=w("success");l.loading=w("loading");l.custom=w("custom");l.dismiss=(e,t)=>{let a={type:3,toastId:e};t?I(t)(a):B(a)};l.dismissAll=e=>l.dismiss(void 0,e);l.remove=(e,t)=>{let a={type:4,toastId:e};t?I(t)(a):B(a)};l.removeAll=e=>l.remove(void 0,e);l.promise=(e,t,a)=>{let r=l.loading(t.loading,{...a,...a?.loading});return typeof e=="function"&&(e=e()),e.then(o=>{let i=t.success?D(t.success,o):void 0;return i?l.success(i,{id:r,...a,...a?.success}):l.dismiss(r),o}).catch(o=>{let i=t.error?D(t.error,o):void 0;i?l.error(i,{id:r,...a,...a?.error}):l.dismiss(r)}),e};var te=1e3,ae=(e,t="default")=>{let{toasts:a,pausedAt:r}=X(e,t),o=ee(new Map).current,i=x((n,m=te)=>{if(o.has(n))return;let d=setTimeout(()=>{o.delete(n),s({type:4,toastId:n})},m);o.set(n,d)},[]);j(()=>{if(r)return;let n=Date.now(),m=a.map(d=>{if(d.duration===1/0)return;let E=(d.duration||0)+d.pauseDuration-(n-d.createdAt);if(E<0){d.visible&&l.dismiss(d.id);return}return setTimeout(()=>l.dismiss(d.id,t),E)});return()=>{m.forEach(d=>d&&clearTimeout(d))}},[a,r,t]);let s=x(I(t),[t]),p=x(()=>{s({type:5,time:Date.now()})},[s]),g=x((n,m)=>{s({type:1,toast:{id:n,height:m}})},[s]),y=x(()=>{r&&s({type:6,time:Date.now()})},[r,s]),c=x((n,m)=>{let{reverseOrder:d=!1,gutter:E=8,defaultPosition:C}=m||{},T=a.filter(u=>(u.position||C)===(n.position||C)&&u.height),V=T.findIndex(u=>u.id===n.id),N=T.filter((u,z)=>z<V&&u.visible).length;return T.filter(u=>u.visible).slice(...d?[N+1]:[0,N]).reduce((u,z)=>u+(z.height||0)+E,0)},[a]);return j(()=>{a.forEach(n=>{if(n.dismissed)i(n.id,n.removeDelay);else{let m=o.get(n.id);m&&(clearTimeout(m),o.delete(n.id))}})},[a,i]),{toasts:a,handlers:{updateHeight:g,startPause:p,endPause:y,calculateOffset:c}}},oe=P`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,ie=P`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,ne=P`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,le=re("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${oe} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${ie} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${ne} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,me=ce`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,pe=de("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${me} 1s linear infinite;
`,fe=U`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,ye=U`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,he=ue("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${fe} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${ye} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,ge=O("div")`
  position: absolute;
`,ve=O("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,be=se`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,xe=O("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${be} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,we=({toast:e})=>{let{icon:t,type:a,iconTheme:r}=e;return t!==void 0?typeof t=="string"?b.createElement(xe,null,t):t:a==="blank"?null:b.createElement(ve,null,b.createElement(pe,{...r}),a!=="loading"&&b.createElement(ge,null,a==="error"?b.createElement(le,{...r}):b.createElement(he,{...r})))},Ee=e=>`
0% {transform: translate3d(0,${e*-200}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,ke=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${e*-150}%,-1px) scale(.6); opacity:0;}
`,$e="0%{opacity:0;} 100%{opacity:1;}",De="0%{opacity:1;} 100%{opacity:0;}",Ie=F("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Te=F("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,ze=(e,t)=>{let a=e.includes("top")?1:-1,[r,o]=L()?[$e,De]:[Ee(a),ke(a)];return{animation:t?`${M(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${M(o)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},Ae=h.memo(({toast:e,position:t,style:a,children:r})=>{let o=e.height?ze(e.position||t||"top-center",e.visible):{opacity:0},i=h.createElement(we,{toast:e}),s=h.createElement(Te,{...e.ariaProps},D(e.message,e));return h.createElement(Ie,{className:e.className,style:{...o,...a,...e.style}},typeof r=="function"?r({icon:i,message:s}):h.createElement(h.Fragment,null,i,s))});Pe(v.createElement);var Ce=({id:e,className:t,style:a,onHeightUpdate:r,children:o})=>{let i=v.useCallback(s=>{if(s){let p=()=>{let g=s.getBoundingClientRect().height;r(e,g)};p(),new MutationObserver(p).observe(s,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return v.createElement("div",{ref:i,className:t,style:a},o)},Ne=(e,t)=>{let a=e.includes("top"),r=a?{top:0}:{bottom:0},o=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:L()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(a?1:-1)}px)`,...r,...o}},je=Oe`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,k=16,Ve=({reverseOrder:e,position:t="top-center",toastOptions:a,gutter:r,children:o,toasterId:i,containerStyle:s,containerClassName:p})=>{let{toasts:g,handlers:y}=ae(a,i);return v.createElement("div",{"data-rht-toaster":i||"",style:{position:"fixed",zIndex:9999,top:k,left:k,right:k,bottom:k,pointerEvents:"none",...s},className:p,onMouseEnter:y.startPause,onMouseLeave:y.endPause},g.map(c=>{let n=c.position||t,m=y.calculateOffset(c,{reverseOrder:e,gutter:r,defaultPosition:t}),d=Ne(n,m);return v.createElement(Ce,{id:c.id,key:c.id,onHeightUpdate:y.updateHeight,className:c.visible?je:"",style:d},c.type==="custom"?D(c.message,c):o?o(c):v.createElement(Ae,{toast:c,position:n}))}))},Ye=l;export{he as CheckmarkIcon,le as ErrorIcon,pe as LoaderIcon,Ae as ToastBar,we as ToastIcon,Ve as Toaster,Ye as default,D as resolveValue,l as toast,ae as useToaster,X as useToasterStore};
//# sourceMappingURL=react-hot-toast.mjs.map