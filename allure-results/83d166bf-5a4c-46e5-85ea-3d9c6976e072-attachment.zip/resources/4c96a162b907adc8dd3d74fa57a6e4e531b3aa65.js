/* esm.sh - react-is@19.2.6 */
export * from "/react-is@19.2.6/es2022/react-is.mjs";
export { default } from "/react-is@19.2.6/es2022/react-is.mjs";
