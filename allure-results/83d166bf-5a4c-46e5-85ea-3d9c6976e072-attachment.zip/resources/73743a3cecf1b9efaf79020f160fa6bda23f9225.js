/* esm.sh - decimal.js-light@2.5.1 */
export * from "/decimal.js-light@2.5.1/es2022/decimal.js-light.mjs";
export { default } from "/decimal.js-light@2.5.1/es2022/decimal.js-light.mjs";
