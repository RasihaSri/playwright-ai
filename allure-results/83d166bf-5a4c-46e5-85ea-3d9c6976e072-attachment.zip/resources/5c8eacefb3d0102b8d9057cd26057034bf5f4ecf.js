/* esm.sh - es-toolkit@1.46.1/compat/sumBy */
export * from "/es-toolkit@1.46.1/es2022/compat/sumBy.mjs";
export { default } from "/es-toolkit@1.46.1/es2022/compat/sumBy.mjs";
