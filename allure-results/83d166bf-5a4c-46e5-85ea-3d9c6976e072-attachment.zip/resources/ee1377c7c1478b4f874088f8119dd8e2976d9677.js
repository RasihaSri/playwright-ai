/* esm.sh - es-toolkit@1.46.1/compat/range */
export * from "/es-toolkit@1.46.1/es2022/compat/range.mjs";
export { default } from "/es-toolkit@1.46.1/es2022/compat/range.mjs";
