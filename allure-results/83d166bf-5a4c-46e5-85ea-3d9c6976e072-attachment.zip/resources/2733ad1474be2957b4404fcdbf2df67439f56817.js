/* esm.sh - react-dom@19.2.6/client */
import "/react-dom@19.2.6/es2022/react-dom.mjs";
import "/react@19.2.6/es2022/react.mjs";
import "/scheduler@^0.27.0?target=es2022";
export * from "/react-dom@19.2.6/es2022/client.mjs";
export { default } from "/react-dom@19.2.6/es2022/client.mjs";
