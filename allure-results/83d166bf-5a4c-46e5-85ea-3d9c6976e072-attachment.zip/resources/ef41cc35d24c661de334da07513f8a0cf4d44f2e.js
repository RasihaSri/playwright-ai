/* esm.sh - d3-interpolate@3.0.1 */
import "/d3-color@^3.1.0?target=es2022";
export * from "/d3-interpolate@3.0.1/es2022/d3-interpolate.mjs";
