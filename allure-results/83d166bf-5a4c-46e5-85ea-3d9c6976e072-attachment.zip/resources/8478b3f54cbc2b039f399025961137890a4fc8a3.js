/* esm.sh - victory-vendor@37.3.6/d3-scale */
import "/d3-scale@^4.0.2?target=es2022";
export * from "/victory-vendor@37.3.6/es2022/d3-scale.mjs";
