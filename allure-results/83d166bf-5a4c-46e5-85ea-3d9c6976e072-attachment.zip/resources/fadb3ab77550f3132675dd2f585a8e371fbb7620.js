/* esm.sh - d3-time-format@4.1.0/src/isoParse */
import{isoSpecifier as a}from"./isoFormat.mjs";import{utcParse as t}from"./defaultLocale.mjs";function o(r){var e=new Date(r);return isNaN(e)?null:e}var i=+new Date("2000-01-01T00:00:00.000Z")?o:t(a),p=i;export{p as default};
//# sourceMappingURL=isoParse.mjs.map