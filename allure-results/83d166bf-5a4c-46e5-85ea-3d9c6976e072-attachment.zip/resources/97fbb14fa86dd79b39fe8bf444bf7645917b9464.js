/* esm.sh - es-toolkit@1.46.1/compat/uniqBy */
export * from "/es-toolkit@1.46.1/es2022/compat/uniqBy.mjs";
export { default } from "/es-toolkit@1.46.1/es2022/compat/uniqBy.mjs";
