/* esm.sh - @reduxjs/toolkit@2.11.2 */
import "/immer@^11.0.0?target=es2022";
import "/redux-thunk@^3.1.0?target=es2022";
import "/redux@^5.0.1?target=es2022";
import "/reselect@^5.1.0?target=es2022";
export * from "/@reduxjs/toolkit@2.11.2/es2022/toolkit.mjs";
