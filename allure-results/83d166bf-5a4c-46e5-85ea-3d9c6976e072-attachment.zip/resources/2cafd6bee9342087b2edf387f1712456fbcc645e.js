/* esm.sh - d3-path@3.1.0 */
export * from "/d3-path@3.1.0/es2022/d3-path.mjs";
