/* esm.sh - tiny-invariant@1.3.3 */
export * from "/tiny-invariant@1.3.3/es2022/tiny-invariant.mjs";
export { default } from "/tiny-invariant@1.3.3/es2022/tiny-invariant.mjs";
