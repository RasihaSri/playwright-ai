/* esm.sh - victory-vendor@37.3.6/d3-shape */
import "/d3-shape@^3.1.0?target=es2022";
export * from "/victory-vendor@37.3.6/es2022/d3-shape.mjs";
