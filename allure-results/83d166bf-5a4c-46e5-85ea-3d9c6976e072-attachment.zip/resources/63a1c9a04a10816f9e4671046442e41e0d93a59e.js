/* esm.sh - es-toolkit@1.46.1/compat/sortBy */
export * from "/es-toolkit@1.46.1/es2022/compat/sortBy.mjs";
export { default } from "/es-toolkit@1.46.1/es2022/compat/sortBy.mjs";
