/* esm.sh - es-toolkit@1.46.1/compat/get */
export * from "/es-toolkit@1.46.1/es2022/compat/get.mjs";
export { default } from "/es-toolkit@1.46.1/es2022/compat/get.mjs";
