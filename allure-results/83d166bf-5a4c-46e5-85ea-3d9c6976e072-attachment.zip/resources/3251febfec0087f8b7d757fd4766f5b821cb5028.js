/* esm.sh - goober@2.1.18 */
export * from "/goober@2.1.18/es2022/goober.mjs";
