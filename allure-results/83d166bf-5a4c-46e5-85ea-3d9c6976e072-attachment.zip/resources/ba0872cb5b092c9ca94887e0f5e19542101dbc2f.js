/* esm.sh - victory-vendor@37.3.6/d3-shape */
export*from"/d3-shape@^3.1.0?target=es2022";
//# sourceMappingURL=d3-shape.mjs.map