/* esm.sh - es-toolkit@1.46.1/compat/throttle */
export * from "/es-toolkit@1.46.1/es2022/compat/throttle.mjs";
export { default } from "/es-toolkit@1.46.1/es2022/compat/throttle.mjs";
