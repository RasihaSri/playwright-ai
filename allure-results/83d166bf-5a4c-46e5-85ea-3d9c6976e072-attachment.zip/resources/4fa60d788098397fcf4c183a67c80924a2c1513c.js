/* esm.sh - use-sync-external-store@1.6.0/shim/with-selector */
import "/react@^19.2.0?target=es2022";
import "/use-sync-external-store@1.6.0/es2022/shim.mjs";
export * from "/use-sync-external-store@1.6.0/es2022/shim/with-selector.mjs";
export { default } from "/use-sync-external-store@1.6.0/es2022/shim/with-selector.mjs";
