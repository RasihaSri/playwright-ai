/* esm.sh - d3-shape@3.2.0 */
import "/d3-path@^3.1.0?target=es2022";
export * from "/d3-shape@3.2.0/es2022/d3-shape.mjs";
