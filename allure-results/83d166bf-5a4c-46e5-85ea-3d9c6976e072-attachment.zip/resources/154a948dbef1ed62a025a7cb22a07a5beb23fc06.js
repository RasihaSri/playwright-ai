/* esm.sh - react-redux@9.2.0 */
import "/react@^19.2.0?target=es2022";
import "/use-sync-external-store@^1.4.0/with-selector?target=es2022";
export * from "/react-redux@9.2.0/es2022/react-redux.mjs";
