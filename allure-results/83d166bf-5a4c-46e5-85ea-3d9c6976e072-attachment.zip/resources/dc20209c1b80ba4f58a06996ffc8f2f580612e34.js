/* esm.sh - lucide-react@0.554.0 */
import "/react@^19.2.0?target=es2022";
export * from "/lucide-react@0.554.0/es2022/lucide-react.mjs";
