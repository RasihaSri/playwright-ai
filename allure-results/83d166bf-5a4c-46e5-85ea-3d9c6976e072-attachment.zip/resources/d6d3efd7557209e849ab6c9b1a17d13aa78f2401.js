/* esm.sh - immer@10.2.0 */
export * from "/immer@10.2.0/es2022/immer.mjs";
