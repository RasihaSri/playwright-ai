/* esm.sh - tiny-invariant@1.3.3 */
var a=!0,n="Invariant failed";function c(t,r){if(!t){if(a)throw new Error(n);var o=typeof r=="function"?r():r,i=o?"".concat(n,": ").concat(o):n;throw new Error(i)}}export{c as default};
//# sourceMappingURL=tiny-invariant.mjs.map