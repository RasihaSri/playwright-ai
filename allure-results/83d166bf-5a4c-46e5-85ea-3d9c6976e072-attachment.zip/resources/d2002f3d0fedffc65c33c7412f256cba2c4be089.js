/* esm.sh - es-toolkit@1.46.1/compat/omit */
export * from "/es-toolkit@1.46.1/es2022/compat/omit.mjs";
export { default } from "/es-toolkit@1.46.1/es2022/compat/omit.mjs";
