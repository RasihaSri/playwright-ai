/* esm.sh - eventemitter3@5.0.4 */
export * from "/eventemitter3@5.0.4/es2022/eventemitter3.mjs";
export { default } from "/eventemitter3@5.0.4/es2022/eventemitter3.mjs";
