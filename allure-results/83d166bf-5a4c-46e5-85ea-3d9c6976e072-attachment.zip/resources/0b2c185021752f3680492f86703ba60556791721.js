/* esm.sh - d3-format@3.1.2 */
import "/d3-format@3.1.2/es2022/src/defaultLocale.mjs";
import "/d3-format@3.1.2/es2022/src/formatSpecifier.mjs";
import "/d3-format@3.1.2/es2022/src/locale.mjs";
import "/d3-format@3.1.2/es2022/src/precisionFixed.mjs";
import "/d3-format@3.1.2/es2022/src/precisionPrefix.mjs";
import "/d3-format@3.1.2/es2022/src/precisionRound.mjs";
export * from "/d3-format@3.1.2/es2022/d3-format.mjs";
