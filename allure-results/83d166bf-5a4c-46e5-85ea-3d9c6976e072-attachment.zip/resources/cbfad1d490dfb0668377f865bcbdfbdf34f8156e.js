/* esm.sh - d3-format@3.1.2/src/formatNumerals */
function e(n){return function(r){return r.replace(/[0-9]/g,function(t){return n[+t]})}}export{e as default};
//# sourceMappingURL=formatNumerals.mjs.map