/* esm.sh - immer@11.1.8 */
export * from "/immer@11.1.8/es2022/immer.mjs";
