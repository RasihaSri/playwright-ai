/* esm.sh - clsx@2.1.1 */
export * from "/clsx@2.1.1/es2022/clsx.mjs";
export { default } from "/clsx@2.1.1/es2022/clsx.mjs";
