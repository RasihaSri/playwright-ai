/* esm.sh - es-toolkit@1.46.1/compat/maxBy */
export * from "/es-toolkit@1.46.1/es2022/compat/maxBy.mjs";
export { default } from "/es-toolkit@1.46.1/es2022/compat/maxBy.mjs";
