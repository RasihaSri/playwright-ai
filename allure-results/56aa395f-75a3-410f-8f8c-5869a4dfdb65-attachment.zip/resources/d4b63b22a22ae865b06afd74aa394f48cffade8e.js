/* The Testing Academy — shared shell behaviour
   ---------------------------------------------
   Wires up:
   - Theme toggle (light <-> dark) with localStorage persistence.
   - Sidebar collapse (desktop) + mobile drawer.
   - Active nav link highlight based on current path.
   - Optional dashboard card search filter (when a [data-card-search] input exists).

   Theme attribute is hydrated synchronously in each page <head>
   before this file loads, so we never flash the wrong theme.        */

(function () {
  "use strict";

  var STORAGE_KEY = "tta-theme";
  var SIDEBAR_KEY = "tta-sidebar-collapsed";
  var root = document.documentElement;

  // ---- Theme toggle ----
  function applyTheme(theme) {
    root.setAttribute("data-theme", theme === "dark" ? "dark" : "light");
    try {
      window.localStorage.setItem(STORAGE_KEY, theme);
    } catch (e) {
      /* ignore storage errors (e.g. private mode) */
    }
  }

  function currentTheme() {
    return root.getAttribute("data-theme") === "dark" ? "dark" : "light";
  }

  function toggleTheme() {
    applyTheme(currentTheme() === "dark" ? "light" : "dark");
  }

  // ---- Sidebar collapse / mobile drawer ----
  function shellEl() {
    return document.querySelector(".tta-shell");
  }

  function setSidebarCollapsed(collapsed) {
    var shell = shellEl();
    if (!shell) return;
    if (collapsed) {
      shell.setAttribute("data-sidebar-collapsed", "true");
    } else {
      shell.removeAttribute("data-sidebar-collapsed");
    }
    try {
      window.localStorage.setItem(SIDEBAR_KEY, collapsed ? "1" : "0");
    } catch (e) {
      /* ignore */
    }
  }

  function toggleSidebar() {
    var shell = shellEl();
    if (!shell) return;
    var isMobile = window.matchMedia("(max-width: 1023px)").matches;
    if (isMobile) {
      var open = shell.getAttribute("data-mobile-open") === "true";
      if (open) {
        shell.removeAttribute("data-mobile-open");
      } else {
        shell.setAttribute("data-mobile-open", "true");
      }
    } else {
      var collapsed = shell.getAttribute("data-sidebar-collapsed") === "true";
      setSidebarCollapsed(!collapsed);
    }
  }

  function closeMobileDrawer() {
    var shell = shellEl();
    if (shell) shell.removeAttribute("data-mobile-open");
  }

  // ---- Sidebar nav icons (hydrated client-side, keeps each HTML page small) ----
  var SVG_NS = "http://www.w3.org/2000/svg";
  var ICON_PATHS = {
    "Overview": '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    "Multiple Element Filter": '<path d="M3 3l7.5 18.5L13 13l8.5-2.5z"/><path d="m13 13 6 6"/>',
    "Web Table Directory": '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    "QA Profile Form": '<rect x="8" y="2" width="8" height="4" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M9 12h6"/><path d="M9 16h6"/>',
    "Companies Table": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 9v12"/>',
    "Tall Buildings Table": '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H2"/><path d="M22 12h-4"/><path d="M10 7h2"/><path d="M10 11h2"/><path d="M10 15h2"/>',
    "Custom Dropdowns": '<rect x="3" y="6" width="18" height="13" rx="2"/><polyline points="8 11 12 15 16 11"/>',
    "Select Box Variants": '<path d="M20.59 13.41 13 21l-9-9V4h8z"/><circle cx="7.5" cy="7.5" r="1.5"/>',
    "Frames overview": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/>',
    "Multi-frame frameset": '<rect x="3" y="3" width="8" height="8"/><rect x="13" y="3" width="8" height="8"/><rect x="3" y="13" width="8" height="8"/><rect x="13" y="13" width="8" height="8"/>',
    "Nested iframes": '<rect x="3" y="3" width="18" height="18" rx="2"/><rect x="6" y="6" width="12" height="12" rx="1.5"/><rect x="9" y="9" width="6" height="6" rx="1"/>',
    "Alerts & Modals": '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    "Windows & Tabs": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 9v12"/>',
    "Upload & Download": '<path d="M12 3v12"/><path d="m6 9 6-6 6 6"/><path d="M21 15v6H3v-6"/>'
  };

  function buildIcon(name) {
    var paths = ICON_PATHS[name];
    if (!paths) return null;
    var wrap = document.createElement("span");
    wrap.innerHTML = '<svg xmlns="' + SVG_NS + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + paths + '</svg>';
    return wrap.firstChild;
  }

  function hydrateNavIcons() {
    var links = document.querySelectorAll(".tta-sidebar-nav .tta-nav-link");
    links.forEach(function (link) {
      var dot = link.querySelector(".nav-dot");
      if (!dot || dot.firstChild) return;
      var label = link.querySelector("span:not(.nav-dot):not(.nav-tag)");
      var name = label ? (label.textContent || "").trim() : "";
      var svg = buildIcon(name);
      if (svg) dot.appendChild(svg);
    });
  }

  // ---- Active nav link ----
  function highlightActiveLink() {
    var path = window.location.pathname.split("/").pop() || "index.html";
    var links = document.querySelectorAll(".tta-sidebar-nav a[href]");
    links.forEach(function (link) {
      var href = link.getAttribute("href") || "";
      var target = href.split("#")[0].split("/").pop();
      if (!target) return;
      if (target === path) {
        link.setAttribute("aria-current", "page");
      }
    });
  }

  // ---- Dashboard card search ----
  function bindCardSearch() {
    var input = document.querySelector("[data-card-search]");
    if (!input) return;
    var cards = Array.prototype.slice.call(
      document.querySelectorAll("[data-card]")
    );
    if (!cards.length) return;

    function applyFilter() {
      var q = (input.value || "").trim().toLowerCase();
      cards.forEach(function (card) {
        var hay = (card.getAttribute("data-card") || card.textContent || "")
          .toLowerCase();
        card.style.display = !q || hay.indexOf(q) !== -1 ? "" : "none";
      });
    }

    input.addEventListener("input", applyFilter);
  }

  // ---- Locator marking toggle ----
  var MARKS_KEY = "tta-marks";

  function applyMarks(on) {
    document.body.setAttribute("data-marks", on ? "on" : "off");
    try {
      window.localStorage.setItem(MARKS_KEY, on ? "1" : "0");
    } catch (e) {
      /* ignore */
    }
    document
      .querySelectorAll("[data-mark-toggle] input")
      .forEach(function (cb) {
        cb.checked = on;
      });
  }

  function bindMarkToggle() {
    var stored = null;
    try {
      stored = window.localStorage.getItem(MARKS_KEY);
    } catch (e) {
      /* ignore */
    }
    var on = stored === null ? true : stored === "1";
    applyMarks(on);

    document
      .querySelectorAll("[data-mark-toggle] input")
      .forEach(function (cb) {
        cb.addEventListener("change", function () {
          applyMarks(cb.checked);
        });
      });
  }

  // ---- Wire up listeners ----
  function init() {
    // Sidebar default state on desktop: respect storage.
    var shell = shellEl();
    if (shell && window.matchMedia("(min-width: 1024px)").matches) {
      var stored = null;
      try {
        stored = window.localStorage.getItem(SIDEBAR_KEY);
      } catch (e) {
        /* ignore */
      }
      if (stored === "1") shell.setAttribute("data-sidebar-collapsed", "true");
    }

    // Theme toggle buttons (sidebar foot + topbar)
    document
      .querySelectorAll("[data-theme-toggle]")
      .forEach(function (btn) {
        btn.addEventListener("click", toggleTheme);
      });

    // Sidebar/mobile toggle buttons
    document
      .querySelectorAll("[data-sidebar-toggle]")
      .forEach(function (btn) {
        btn.addEventListener("click", toggleSidebar);
      });

    // Backdrop click closes the mobile drawer
    document
      .querySelectorAll("[data-mobile-close]")
      .forEach(function (el) {
        el.addEventListener("click", closeMobileDrawer);
      });

    // Close mobile drawer when a sidebar link is clicked.
    document
      .querySelectorAll(".tta-sidebar-nav a[href]")
      .forEach(function (a) {
        a.addEventListener("click", function () {
          if (window.matchMedia("(max-width: 1023px)").matches) {
            closeMobileDrawer();
          }
        });
      });

    hydrateNavIcons();
    highlightActiveLink();
    bindCardSearch();
    bindMarkToggle();
    bindTabs();
  }

  // ---- Page tabs (Page / Practice / Solution) ----
  function bindTabs() {
    document.querySelectorAll('[role="tablist"].tta-tabs').forEach(function (list) {
      var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));
      if (!tabs.length) return;

      function selectTab(tab, focus) {
        tabs.forEach(function (t) {
          var isMe = t === tab;
          t.setAttribute("aria-selected", isMe ? "true" : "false");
          t.tabIndex = isMe ? 0 : -1;
          var panelId = t.getAttribute("aria-controls");
          var panel = panelId && document.getElementById(panelId);
          if (panel) {
            if (isMe) panel.removeAttribute("hidden");
            else panel.setAttribute("hidden", "");
          }
        });
        if (focus) tab.focus();
        var key = tab.dataset.testid || tab.id || "";
        if (key && history && history.replaceState) {
          var hash = key.replace(/^tab-/, "");
          if (hash) history.replaceState(null, "", "#" + hash);
        }
      }

      // Initial selection — honour URL hash if it matches one of the tabs.
      var hash = window.location.hash.replace(/^#/, "");
      var initial = null;
      if (hash) {
        initial = tabs.find(function (t) {
          return (t.dataset.testid || "").replace(/^tab-/, "") === hash;
        });
      }
      if (!initial) initial = tabs.find(function (t) { return t.getAttribute("aria-selected") === "true"; }) || tabs[0];
      selectTab(initial, false);

      tabs.forEach(function (tab) {
        tab.addEventListener("click", function () { selectTab(tab, false); });
        tab.addEventListener("keydown", function (event) {
          var idx = tabs.indexOf(tab);
          if (event.key === "ArrowRight") { selectTab(tabs[(idx + 1) % tabs.length], true); event.preventDefault(); }
          else if (event.key === "ArrowLeft") { selectTab(tabs[(idx - 1 + tabs.length) % tabs.length], true); event.preventDefault(); }
          else if (event.key === "Home") { selectTab(tabs[0], true); event.preventDefault(); }
          else if (event.key === "End") { selectTab(tabs[tabs.length - 1], true); event.preventDefault(); }
        });
      });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
